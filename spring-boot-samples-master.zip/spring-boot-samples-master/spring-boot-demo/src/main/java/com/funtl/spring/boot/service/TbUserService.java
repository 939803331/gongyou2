package com.funtl.spring.boot.service;

public interface TbUserService{


}
