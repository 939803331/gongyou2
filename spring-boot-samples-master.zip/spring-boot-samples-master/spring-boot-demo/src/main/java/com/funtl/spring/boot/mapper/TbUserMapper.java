package com.funtl.spring.boot.mapper;

import com.funtl.spring.boot.domain.TbUser;
import tk.mybatis.mapper.MyMapper;

public interface TbUserMapper extends MyMapper<TbUser> {
}