package com.funtl.oauth2.resource.mapper;

import com.funtl.oauth2.resource.domain.TbContentCategory;
import tk.mybatis.mapper.MyMapper;

public interface TbContentCategoryMapper extends MyMapper<TbContentCategory> {
}