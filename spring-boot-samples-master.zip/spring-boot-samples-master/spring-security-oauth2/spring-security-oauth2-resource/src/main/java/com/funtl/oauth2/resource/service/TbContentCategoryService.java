package com.funtl.oauth2.resource.service;

public interface TbContentCategoryService{

}
