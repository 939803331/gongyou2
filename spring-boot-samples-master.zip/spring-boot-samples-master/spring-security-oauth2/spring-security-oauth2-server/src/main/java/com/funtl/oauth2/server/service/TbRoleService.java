package com.funtl.oauth2.server.service;

public interface TbRoleService {

}
