package com.funtl.oauth2.server.mapper;

import com.funtl.oauth2.server.domain.TbUser;
import tk.mybatis.mapper.MyMapper;

public interface TbUserMapper extends MyMapper<TbUser> {
}