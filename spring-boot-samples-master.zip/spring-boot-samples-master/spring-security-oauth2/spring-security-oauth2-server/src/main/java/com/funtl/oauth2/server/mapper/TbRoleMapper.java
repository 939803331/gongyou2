package com.funtl.oauth2.server.mapper;

import com.funtl.oauth2.server.domain.TbRole;
import tk.mybatis.mapper.MyMapper;

public interface TbRoleMapper extends MyMapper<TbRole> {
}