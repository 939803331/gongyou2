package com.funtl.spring.cloud.alibaba.dubbo.provider.api;

public interface EchoService {
    String echo(String string);
}
